



// var key= false;
function ChangeSlide() {
    if (key==false) {
      TweenMax.to(".squares-avenue-1", 0, {opacity: 0});
      TweenMax.to(".squares-avenue-1", 0, {display: 'none'});                  
      TweenMax.to(".squares-avenue-2", 0, {opacity: 1});
      TweenMax.to(".squares-avenue-2", 0, {display: 'block'});                   
      key=true;
  }
  else {
      TweenMax.to(".squares-avenue-2", 0, {opacity: 0});
      TweenMax.to(".squares-avenue-2", 0, {display: 'none'});                  
      TweenMax.to(".squares-avenue-1", 0, {opacity: 1});
      TweenMax.to(".squares-avenue-1", 0, {display: 'block'});                   
      key=false;
  }
}


