
	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		<?php get_template_part( 'template-parts/footer/footer', 'widgets' ); ?>
		
			
		
		</div><!-- .site-info -->
	</footer><!-- #colophon -->

</div><!-- #page -->


<link rel="stylesheet" type="text/css" href="<?php bloginfo("template_directory"); ?>/css/owl.carousel.min.css">
  <link rel="stylesheet" href="<?php bloginfo("template_directory"); ?>/css/style.css">
  <script src="<?php bloginfo("template_directory"); ?>/js/jquery.min.js"></script>
  <script src="<?php bloginfo("template_directory"); ?>/js/jquery.mousewheel.min.js"></script>
  <script src="<?php bloginfo("template_directory"); ?>/js/owl.carousel.js"></script>
  <script src="<?php bloginfo("template_directory"); ?>/js/TweenMax.min.js"></script>
<?php wp_footer(); ?>
<script>
function caretUp() {
  document.getElementById("down").style.display = "none";
document.getElementById("up").style.display = "block";
}

function caretDown() {
  document.getElementById("up").style.display = "none";
document.getElementById("down").style.display = "block";
}
</script>
<script>
function caretUp2() {
  document.getElementById("down2").style.display = "none";
document.getElementById("up2").style.display = "block";
}

function caretDown2() {
  document.getElementById("up2").style.display = "none";
document.getElementById("down2").style.display = "block";
}
</script>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "450px";
	document.getElementById("cls").style.right = "55px";
	 document.getElementById("down").style.right = "55px";
   document.body.style.backgroundColor = "rgba(0,0,0,0.8)";
	document.getElementById("down").style.display = "block";
	document.getElementById("down2").style.display = "block";
	document.getElementById("up").style.display = "none";
	document.getElementById("overlay").style.display = "block";

}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
 document.getElementById("cls").style.right = "-450px";
	 document.getElementById("down").style.right = "-450px";
	document.getElementById("down").style.display = "none";
	 document.getElementById("down2").style.right = "-450px";
	document.getElementById("down2").style.display = "none";
  document.body.style.backgroundColor = "white";
}
</script>
<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>
 

  <script>
    $(document).ready(function () {
      TweenMax.to(".squares-avenue-1", 0, {x:500});
      TweenMax.to(".squares-avenue-2", 0, {x:500});
      TweenMax.to(".squares-avenue-1", 2, {x:-30});
      TweenMax.to(".square, .rectangle", 3, {opacity:1});
      var owl = $('.owl-carousel');
      owl.owlCarousel({
          loop:true,
          nav:false,
          margin:10,
          responsive:{
              0:{
                  items: 1
              }
          }
      });
      var key=false

      function ShowSlide2() {
                    TweenMax.to(".squares-avenue-1", 0, {opacity: 0});
                    TweenMax.to(".squares-avenue-1", 0, {display: 'none'});
                    TweenMax.to(".squares-avenue-2", 0, {opacity: 1});
                    TweenMax.to(".squares-avenue-2", 0, {display: 'block'});
                    TweenMax.to(".squares-avenue-2", 2, {x:-30});
      }
      function ShowSlide1() {
                    TweenMax.to(".squares-avenue-2", 0, {opacity: 0});
                    TweenMax.to(".squares-avenue-2", 0, {display: 'none'});
                    TweenMax.to(".squares-avenue-1", 0, {opacity: 1});
                    TweenMax.to(".squares-avenue-1", 0, {display: 'block'});
                    TweenMax.to(".squares-avenue-1", 2, {x:-30});
      }


      $('#next').click(function() {
        owl.trigger('next.owl');
        if (key==false) {
                    ShowSlide2()
                    key=true;
                }
                else {
                    ShowSlide1()
                    key=false;
                }
      })

      
      $('#prev').click(function() {
        owl.trigger('prev.owl');
        if (key==false) {
                    ShowSlide2()
                    key=true;
                }
                else {
                  ShowSlide1()
                    key=false;
                }
      })

      owl.on('mousewheel', '.owl-stage', function (e) {
          if (e.deltaY>0) {
            owl.trigger('next.owl');
                if (key==false) {
                  ShowSlide2()                
                    key=true;
                }
                else {
                  ShowSlide1()                
                    key=false;
                }
           
          } else {
            owl.trigger('prev.owl');
            if (key==false) {
                    ShowSlide2()
                    key=true;
                }
                else {
                  ShowSlide1()
                    key=false;
                }
          }
          e.preventDefault();
      });

    });

  </script>
</body>
</html>
