<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<?php wp_head(); ?>
<head>
  <title>Scroll Test</title>

  <style>
    .owl-carousel {
      width: 100%;
      overflow: hidden;
    }
    .owl-item {
      width: 100%;
      height: 100vh;
      line-height: 200px;
      font-size: 100px;
      color: #fff;
      text-align: center;
    }
    .owl-nav {
    position: absolute;
    bottom: 50px;
    left: 50px;
}
  </style>

</head>

<body>
