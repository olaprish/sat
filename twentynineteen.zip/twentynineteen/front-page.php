<?php
/*
Template Name: Front-page
Template Post Type:page*/
get_header();
?>
<nav>
<?php if ( has_custom_logo() ) : ?>
	<li class="logo" style="float:left"> 
		<div class="site-logo">
		 <?php the_custom_logo(); ?> 
			<div class="sat-descr">	
					зернотрейдер та інвестор агробізнесу
		</div>
		</div> 
		
	</li>
<?php endif; ?>
<ul class="topnav">
    <li class="contact"><a href="#">контакти</a></li>
    <li class="lng"> <a href="">EN</a>
        <a href="">UA</a>
        <a href="">RU</a> </li>
    <li class="mob" onclick="openNav()"></li>
</ul>
</nav>
<div id="mySidenav" class="sidenav">
    <span class="closebtn" id="cls" onclick="closeNav()"></span>
    <ul class="side">
        <a href="#">Головна</a>
        <a href="#contact">Про нас</a>
        <button class="dropdown-btn">Дільність
            <i class="fas fa-chevron-down" id="down2" onclick="caretUp2()"></i>
            <i class="fas fa-chevron-up" id="up2" onclick="caretDown2()"></i>
        </button>
        <div class="dropdown-container">
            <a href="#">закупівлі</a>
            <a href="#">продаж</a>
            <a href="#">добрива</a>
            <a href="#">агент</a>
            <a href="#">рослинництво</a>
            <a href="#">сільгосптехніка</a>
            <a href="#">елеватор</a>
            <a href="#">інвестиції</a>
        </div>
        <button class="dropdown-btn">sat lab
            <i class="fas fa-chevron-down" id="down" onclick="caretUp()"></i>
            <i class="fas fa-chevron-up" id="up" onclick="caretDown()"></i>
        </button>
        <div class="dropdown-container">
            <a href="#">закупівлі</a>
            <a href="#">продаж</a>
        </div>
        <a href="#">Кар'єра</a>
        <a href="#contact">новини</a>
        <a href="#contact">контакти</a>
    </ul>
</div>

  <div class="nav-slider">    
    <span id="prev"></span><span id="next"></span>
  </div>

    <div class="owl-carousel">
                <div class="home-wrapper-1">
                        <div class="page-wrapper"> 
                               <div class="page-container">
                                   <div class="squares-avenue-1">
                                       <div class="row">
                                        <a href="#" class="square bg-yellow">
                                          <img class="ico" src="img/wheat_bag.svg" alt="">
                                          <div class="title">Закупівлі</div>
                                        </a>
                                        <div class="square bg-blue">2</div>                   
                                       </div>
                                       <div class="row">
                                          <div class="rectangle">3</div> 
                                       </div>               
                                       <div class="row">               
                                          <div class="square bg-yellow">1</div>
                                        <div class="square bg-green">2</div>
                                       </div>
                                   </div>
                               </div>
                        </div>  
                </div>

                <div class="home-wrapper-2">
                        <div class="page-wrapper"> 
                                <div class="page-container">
                                    <div class="squares-avenue-2">
                                         <div class="row">
                                          <div class="square bg-dark-blue">1</div>
                                          <div class="square bg-see-blue">2</div>                   
                                         </div>
                                         <div class="row">
                                          <div class="square bg-blue">1</div>
                                         <div class="square bg-green">2</div>
                                         </div>               
                                         <div class="row">               
                                          <div class="square bg-yellow">1</div>
                                         <div class="square bg-orange">2</div>
                                         </div>
                                     </div>
                                </div>
                         </div>
                </div>


    </div>

<?php
get_footer();
