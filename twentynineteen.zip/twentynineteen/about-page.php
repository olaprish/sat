<?php
/*
Template Name: About
Template Post Type:page*/

get_header();
?>

<section id ="header_about">
	<div class="overlay">
	</div>	
<nav>
	<?php if ( has_custom_logo() ) : ?>
	<li class="logo" style="float:left"> 
		<div class="site-logo">
		 <?php the_custom_logo(); ?> 
		</div> 
	</li>
<?php endif; ?>
<ul class="topnav">
    <li class="contact"><a href="#">контакти</a></li>
    <li class="lng"> <a href="">EN</a>
        <a href="">UA</a>
        <a href="">RU</a> </li>
    <li class="mob" onclick="openNav()"></li>
</ul>
</nav>
<div id="mySidenav" class="sidenav">
    <span class="closebtn" id="cls" onclick="closeNav()"></span>
    <ul class="side">
        <a href="#">Головна</a>
        <a href="#contact">Про нас</a>
        <button class="dropdown-btn">Дільність
            <i class="fas fa-chevron-down" id="down2" onclick="caretUp2()"></i>
            <i class="fas fa-chevron-up" id="up2" onclick="caretDown2()"></i>
        </button>
        <div class="dropdown-container">
            <a href="#">закупівлі</a>
            <a href="#">продаж</a>
            <a href="#">добрива</a>
            <a href="#">агент</a>
            <a href="#">рослинництво</a>
            <a href="#">сільгосптехніка</a>
            <a href="#">елеватор</a>
            <a href="#">інвестиції</a>
        </div>
        <button class="dropdown-btn">sat lab
            <i class="fas fa-chevron-down" id="down" onclick="caretUp()"></i>
            <i class="fas fa-chevron-up" id="up" onclick="caretDown()"></i>
        </button>
        <div class="dropdown-container">
            <a href="#">закупівлі</a>
            <a href="#">продаж</a>
        </div>
        <a href="#">Кар'єра</a>
        <a href="#contact">новини</a>
        <a href="#contact">контакти</a>
    </ul>
</div>
 <div class="heading">
 <h1 class ="top-title">зернотрейдер та інвестор
агробізнесу</h1>

</div>
	<div class="go">
		<button class="blue" href=""><span class="play"></span>
 переглянути
	</button>
		</div>
</section>

	<section id="primary" class="content-area">
		<main id="main" class="site-main">

			<?php

			/* Start the Loop */
			while ( have_posts() ) :
				the_post();

				get_template_part( 'template-parts/content/content', 'page' );

			endwhile; // End of the loop.
			?>

		</main><!-- #main -->
	</section><!-- #primary -->

<?php
get_footer();
